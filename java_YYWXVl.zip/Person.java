// Jwaun Huntley
// 5-28-19

// Module 8 Lab Activity


public class Person
{
 private String name;

 
  public String getName()
  {
    return name;
}
	public void setName(String newName)
    {
      	name = newName;
    }
  
  public static void main(String[] args) {
   Person oliver = new Person (); 
   oliver.setName("Queen");
    System.out.println(oliver.getName());
  }
}


//Jwaun Huntley
  